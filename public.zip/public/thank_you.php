<?php require_once("../resources/config.php"); ?>
<?php require_once("../resources/cart.php"); ?>

<!DOCTYPE html>
<html>
<head>
<title>
Fine-Choice-Shopping-Mart
</title>
<link rel='stylesheet' type="text/css" href='proj.css'/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel='stylesheet' type="text/css" href="customelogin.css">
</head> 
<body>   
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>
<?php
report();
?>
<div class="container">
	<h1 class="text-center">Thank you</h1>
</div>
</body>
</html>
